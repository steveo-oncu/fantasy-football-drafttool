# Draft Board

An auction-draft command centre for a 10-team, $600 PPR keeper league. Single file, no
build step, no dependencies, works offline once loaded. Built for use on an iPad during
a live draft.

## What it does

- **Bid check** — type a player and the current bid, get a green/amber/red call. The
  ceiling accounts for the money you must hold back to fill your remaining roster spots.
- **Live inflation** — recalculates the market after every pick. Cash still in the room
  divided by the value of the players still worth buying. Player values move with it.
- **Every pick, every team** — record who won each player and at what price. Rival
  budgets and their maximum possible bid update as you go, sorted so the teams that can
  actually outbid you sit at the top.
- **Roster and byes** — starters slot automatically, flex included, with a warning when
  a single bye week would take out two or more of your starters.
- **Undo and backup** — one tap to reverse a mis-tap, and a JSON export so a browser
  clearing its storage mid-draft doesn't cost you the day.

## The league

10 teams, $600 budget, $5 minimum, 15 roster spots, full PPR. Eight teams carried
keepers into the auction; two are new and start with the full $600 and all 15 spots
open. Keeper salaries come out of the budget.

Tap **Fix details** to correct team names, keeper prices, or the starting lineup.
Everything already recorded survives the edit, so it is safe to use mid-draft — handy
when a keeper is announced late or someone's price turns out to be wrong.

Keepers use `Team | Player | Price`, one per line. Names not in the player pool are
still marked as drafted, they just carry no value.

## Player values

Sourced from FFToday's 2026 PPR auction board (8/20/26), which is published for a
12-team, $200, 18-spot league. Those numbers do not transfer directly to other formats,
so the page rescales them: the dollars above the league minimum are redistributed in
proportion to the discretionary money actually available in your league.

Bye weeks are the 2026 NFL schedule.

Values assume full PPR. If your league uses half-PPR or standard, treat pass-catching
backs and slot receivers as somewhat cheaper than shown.

## Publishing

`index.html` is the whole application. Put it in the repository root, then
**Settings → Pages → Deploy from branch → `main` → `/ (root)`**.

Nothing leaves the browser. Draft state lives in local storage on the device you are
using, which is why the backup button exists.

Drafting on hotel or venue wifi is a bad bet. Open the page once beforehand and it will
keep working if the connection drops, since everything runs client-side and state lives
in browser storage.
